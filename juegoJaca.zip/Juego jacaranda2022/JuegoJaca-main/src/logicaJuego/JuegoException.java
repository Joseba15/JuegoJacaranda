package logicaJuego;

public class JuegoException extends Exception {

	public JuegoException(String string) {
		// TODO Auto-generated constructor stub
	}

}
